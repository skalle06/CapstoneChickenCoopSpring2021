/*
 * ArduinoCore.cpp
 *
 * Created: 2/9/2020 12:56:25 PM
 * Author : natha
 */ 

#include <avr/io.h>


/* Replace with your library code */
int myfunc(void)
{
	return 0;
}

