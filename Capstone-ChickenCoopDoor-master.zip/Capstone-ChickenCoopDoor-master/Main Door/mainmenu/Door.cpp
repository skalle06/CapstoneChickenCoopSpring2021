#ifdef constant_parameters_h
#include "./constant_parameters.h"
#endif

#include "./Door.h"

Door::Door()
{
    _set = Settings::Settings();
}
Door::Door(Settings set)
{
    _set = set;
}

void Door::Initialize()
{

}

void Door::OpenDoor()
{

}

void Door::CloseDoor()
{

}