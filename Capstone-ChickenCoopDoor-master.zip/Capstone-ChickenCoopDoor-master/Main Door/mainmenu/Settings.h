#include "./DayNightSettings.h";

class Settings{
    public: DayNightSettings MorningSettings;
    public: DayNightSettings EveningSettings;
};