struct DayNightSettings{
    double temp;
    int lumens;
    int timeToActivate;
};
