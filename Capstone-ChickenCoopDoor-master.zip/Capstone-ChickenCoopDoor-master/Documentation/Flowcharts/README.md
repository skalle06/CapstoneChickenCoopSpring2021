# Flowcharts
Flowcharts are created in Microsoft Visio as a representation of the software architecture.
