## Demo
For use on demo-day only. Code sections may be used in later segments, but no optimzations for power saving, interrupt usage, or non-critical features are included.
